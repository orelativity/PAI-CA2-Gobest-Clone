import json
from pathlib import Path

import numpy as np
import pandas as pd
import joblib

from .feature_engineer import engineer_features_from_raw_tables
from .db import save_predictions, update_driver_history


def get_sprint2_dir() -> Path:
    """
    resolves the 'Sprint 2' directory reliably from this file location
    """
    here = Path(__file__).resolve()
    cur = here
    for _ in range(15):
        if cur.name == "Sprint 2":
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    raise FileNotFoundError(f"cannot locate 'Sprint 2' folder from: {here}")


def load_bundle():
    """
    expected files:
    Sprint 2/Modelling/models/xgboost_best_model.joblib
    Sprint 2/Modelling/models/xgboost_scaler.joblib
    Sprint 2/Modelling/models/xgboost_feature_cols.json
    """
    sprint2 = get_sprint2_dir()
    models_dir = sprint2 / "Modelling" / "models"

    model_path = models_dir / "xgboost_best_model.joblib"
    scaler_path = models_dir / "xgboost_scaler.joblib"
    cols_path = models_dir / "xgboost_feature_cols.json"

    if not model_path.exists():
        raise FileNotFoundError(f"missing model: {model_path}")
    if not scaler_path.exists():
        raise FileNotFoundError(f"missing scaler: {scaler_path}")
    if not cols_path.exists():
        raise FileNotFoundError(f"missing feature cols: {cols_path}")

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    feature_cols = json.loads(cols_path.read_text(encoding="utf-8"))

    return model, scaler, feature_cols


def clean_features(df_engineered: pd.DataFrame, feature_cols):
    """
    aligns engineered df to training schema
    """
    df = df_engineered.copy()

    for c in feature_cols:
        if c not in df.columns:
            df[c] = 0

    df = df[feature_cols]

    for c in feature_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna(df.median(numeric_only=True))

    return df


def predict_from_raw(sensor_df, driver_df, safety_df, threshold: float):
    """
    end-to-end:
    raw dfs -> engineered features -> xgboost -> preds df
    also writes results to sqlite history
    """
    if threshold <= 0 or threshold >= 1:
        raise ValueError("threshold must be between 0 and 1")

    engineered = engineer_features_from_raw_tables(sensor_df, driver_df, safety_df)

    if "driver_id" not in engineered.columns:
        raise ValueError("engineered data missing driver_id. check safety_labels driver_id mapping")

    model, scaler, feature_cols = load_bundle()

    X = clean_features(engineered, feature_cols)
    Xs = scaler.transform(X)

    if not hasattr(model, "predict_proba"):
        raise ValueError("loaded model does not support predict_proba")

    proba = model.predict_proba(Xs)[:, 1]
    pred = (proba >= threshold).astype(int)

    out = engineered.copy()
    out["pred_proba"] = proba
    out["pred_label"] = pred
    out["threshold_used"] = float(threshold)

    # write history
    save_predictions(out[["bookingID", "driver_id", "pred_proba", "pred_label"]], threshold)
    update_driver_history(out)

    return out
